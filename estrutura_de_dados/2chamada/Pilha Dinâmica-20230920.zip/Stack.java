package Stack;

public class Stack<T> {
    private Node<T> top;
    private int height;
    
    public Stack(){
        top = null;   
        height = 0;     
    }

    public Stack(T value){
        Node<T> newNode = new Node<T>(value);
        if(top==null){
            top = newNode;
        }
        height = 1;     
    }

    public void printStack(){
        Node<T> startNode = top;
        while(startNode!=null){
            System.out.println("["+startNode.value+"]");
            startNode = startNode.next;
        }
    }
  
    public T pop(){
        if(top==null){
            throw new RuntimeException("Pila vazia.");
        }
        Node<T> poppedNode = top;
        top = top.next;
        poppedNode.next = null;
        height--;
        return poppedNode.value;
    }

    public void push(T value){
        Node<T> newNode = new Node<T>(value);
        if(top==null){
            top = newNode;
        }else{
            newNode.next = top;
            top = newNode;
        }
        height++;
    }

    public T peek(){
        return top.value;
    }

}
